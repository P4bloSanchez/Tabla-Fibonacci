//
//  SecondViewController.swift
//  Fibonacci_Projeckt
//
//  Created by Alumno on 23/10/23.
//

import UIKit

class SecondViewController: UIViewController{
    
    @IBOutlet weak var caja: UILabel!
    var arreglo : [String] = []
    var n : Int32 = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let sucesion = arreglo.joined(separator: ", ")
        caja.text = sucesion

    }

}
